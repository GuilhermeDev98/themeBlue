        <footer>
            <div class="section">
                <div id="contact">
                    <div class="title">Contato</div>
                    <div class="content">
                        <?php /* colocar email do dono */ ?>
                        <i class="fa fa-envelope-o"></i> example@gmail.com
                    </div>
                </div>
                <div id="social">
                    <div class="title">Redes Sociais</div>
                    <div class="content">
                        <a href=""><i class="fa fa-facebook-official"></i></a>
                        <a href=""><i class="fa fa-google-plus"></i></a>
                        <a href=""><i class="fa fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div id="developer">
                <i class="fa fa-coffee"></i> Developed By: <a href="http://www.guilhermedev.com">GuilhermeDev</a>
            </div>
        </footer>
    </body>
</html>
